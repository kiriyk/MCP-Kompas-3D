# Dice Tower V2.1 — native KOMPAS-3D v21 example

Open 00-dice-tower.a3d with all 27 M3D files in the same extracted directory.
The drawings/ directory contains 28 associated CDW drawings and their PDF exports.
The assembly has 42 component instances; fasteners and glue are not modeled.

KOMPAS native files can retain absolute source paths from the authoring machine.
If references cannot be found, point them to the extracted M3D/A3D files before
rebuilding model views. Keep the complete directory together.

This is an educational SDK/MCP example. It uses simplified character reliefs.
Physical dice motion, printing tolerances and strength require a prototype.
Native checks of the saved sample found no volumetric interference in 861 pairs.
The manifest contains relative filenames and SHA256 checksums, no diagnostic logs.
